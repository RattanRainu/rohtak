package com.wot.rohtakhospital;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ActiveQryAdapter extends RecyclerView.Adapter<ActiveQryAdapter.MyViewHolder> {

    private ArrayList<ModalActiveQry> arrayList;
    private Context context;

    public ActiveQryAdapter(ArrayList<ModalActiveQry> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.content_active_qry, viewGroup, false);
        return new ActiveQryAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        final ModalActiveQry data = arrayList.get(i);

        myViewHolder._senderName.setText(data.get_sendername());
        myViewHolder._content.setText(data.get_message());
        myViewHolder._date.setText(data.get_date());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView _senderName, _content , _date;

        public MyViewHolder(View itemView) {
            super(itemView);
            _senderName = itemView.findViewById(R.id.txtSenderName);
            _content = itemView.findViewById(R.id.txtMsgContent);
            _date = itemView.findViewById(R.id.txtDate);
        }
    }
}

