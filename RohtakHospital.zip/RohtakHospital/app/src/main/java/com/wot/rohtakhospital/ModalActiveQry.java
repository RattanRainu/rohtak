package com.wot.rohtakhospital;

public class ModalActiveQry {

    private String _sendername;
    private String _message;
    private String _sendertype;
    private String _senderid;
    private String _date;
    private String _status;


    public ModalActiveQry(String _sendername, String _message, String _sendertype, String _senderid, String _date, String _status) {
        this._sendername = _sendername;
        this._message = _message;
        this._sendertype = _sendertype;
        this._senderid = _senderid;
        this._date = _date;
        this._status = _status;
    }

    public String get_sendername() {
        return _sendername;
    }

    public void set_sendername(String _sendername) {
        this._sendername = _sendername;
    }

    public String get_message() {
        return _message;
    }

    public void set_message(String _message) {
        this._message = _message;
    }

    public String get_sendertype() {
        return _sendertype;
    }

    public void set_sendertype(String _sendertype) {
        this._sendertype = _sendertype;
    }

    public String get_senderid() {
        return _senderid;
    }

    public void set_senderid(String _senderid) {
        this._senderid = _senderid;
    }

    public String get_date() {
        return _date;
    }

    public void set_date(String _date) {
        this._date = _date;
    }

    public String get_status() {
        return _status;
    }

    public void set_status(String _status) {
        this._status = _status;
    }

}
