package com.wot.rohtakhospital;

public class URLs {

    private static final String ROOT_URL = "http://ashnoor.in/rohtak/serv/functions.php?apicall=";

    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_ADMIN_LOGIN= ROOT_URL + "adminlogin";
    public static final String URL_ACTIVE_QRY_LIST = ROOT_URL + "activeqrylist";
}
