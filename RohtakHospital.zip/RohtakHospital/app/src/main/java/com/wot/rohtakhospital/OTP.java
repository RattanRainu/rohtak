package com.wot.rohtakhospital;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Console;
import java.util.HashMap;
import java.util.Map;


public class OTP extends AppCompatActivity {

    private  Intent getintent;
    private ProgressDialog progressDialog;
    private SharedPrefManager sharedPrefManagerConfig;
    String mobileNo;
    String stringOTP = "Your OTP is 0000";
    Handler handler;
    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);

        final TextView resendOTP;

        final PinEntryEditText pinEntry = findViewById(R.id.txt_pin_entry);
        sharedPrefManagerConfig = new SharedPrefManager(getApplicationContext());
        progressDialog=new ProgressDialog(OTP.this);
        progressDialog.setMessage("Please wait...");
        progressDialog.setIndeterminate(true);
        progressDialog.setCanceledOnTouchOutside(false);
        handler = new Handler();

        getintent = getIntent();
        mobileNo= getintent.getStringExtra("mobile");
        if (pinEntry != null) {
            pinEntry.setOnPinEnteredListener(new PinEntryEditText.OnPinEnteredListener() {
                @Override
                public void onPinEntered(CharSequence str) {
                    if (str.toString().equals(stringOTP.substring(stringOTP.length() - 4))) {
                            Intent intent = new Intent(OTP.this,SignUp.class);
                            intent.putExtra("mobile",mobileNo);
                            startActivity(intent);
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                            finish();
                    } else {
                        Toast.makeText(OTP.this, "Invalid code", Toast.LENGTH_SHORT).show();
                        pinEntry.setText(null);
                    }
                }
            });
        }
        getOTP();

    }


    @Override
    public void onBackPressed() {
        startActivity(new Intent(this,MainActivity.class));
        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
        finish();
    }



    public void getOTP(){

        final StringRequest stringRequest = new StringRequest(Request.Method.POST, URLs.URL_ACTIVE_QRY_LIST,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("MessageData");
                            JSONObject object = jsonArray.getJSONObject(0);
                            stringOTP = object.getString("Message");


                            runnable = new Runnable() {
                                @Override
                                public void run() {
                                    stringOTP = "Your OTP is 0000";
                                }
                            };
                            handler.postDelayed(runnable, 120000L);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("mobile_no","91" + mobileNo);
                Log.d("MOBILERTN", "getParams: " + mobileNo);
                return params;

            }
        };
        VolleySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

}