package com.wot.rohtakhospital;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {

    private SharedPreferences sharedPrefManager;
    private Context context;

    private static final String SHARED_PREF_NAME = "simplifiedcodingsharedpref";
    private static final String KEY_NAME_LOGIN = "login";
    private static final String KEY_NAME_ID = "id";
    private static final String KEY_NAME_PROFILE = "profile";
    private static final String KEY_NAME_USER_NAME = "name";
    private static final String KEY_NAME_USER_IMAGE = "image";
    private static final String KEY_NAME_USER_CHECK_IMAGE = "checkImage";


    public SharedPrefManager(Context context) {
        context = context;
        sharedPrefManager =context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
    }

    //this method will store the user data in shared preferences

    public void writeUserLogin(boolean status) {
        SharedPreferences.Editor editor = sharedPrefManager.edit();
        editor.putBoolean(KEY_NAME_LOGIN,status);
        editor.commit();
    }

    //this method will checker whether user is already logged in or not
    public boolean readUserLoggin() {
        boolean status = false;
        status = sharedPrefManager.getBoolean(KEY_NAME_LOGIN,false);
        return status;
    }

    public void writeUserID(int id){
        SharedPreferences.Editor editor = sharedPrefManager.edit();
        editor.putInt(KEY_NAME_ID,id);
        editor.commit();
    }
    public int readUserID(){
        int id = sharedPrefManager.getInt(KEY_NAME_ID,0);
        return  id;

    }
    public void writeUserProfile(Boolean profile){
        SharedPreferences.Editor editor = sharedPrefManager.edit();
        editor.putBoolean(KEY_NAME_PROFILE,profile);
        editor.commit();
    }

    public Boolean readUserProfile(){
        Boolean profile = sharedPrefManager.getBoolean(KEY_NAME_PROFILE,false);
        return profile;
    }

    public void writeUserName(String name){
        SharedPreferences.Editor editor = sharedPrefManager.edit();
        editor.putString(KEY_NAME_USER_NAME,name);
        editor.commit();
    }

    public String readUserName(){
        String name = sharedPrefManager.getString(KEY_NAME_USER_NAME,"");
        return name;
    }

    public void writeUserCheckImage(String imgCheck){
        SharedPreferences.Editor editor = sharedPrefManager.edit();
        editor.putString(KEY_NAME_USER_CHECK_IMAGE,imgCheck);
        editor.commit();
    }

    public String readUserCheckImage(){
        String imgCheck = sharedPrefManager.getString(KEY_NAME_USER_CHECK_IMAGE,"N");
        return imgCheck;
    }

    public void writeUserImage(String imgPath){
        SharedPreferences.Editor editor = sharedPrefManager.edit();
        editor.putString(KEY_NAME_USER_IMAGE,imgPath);
        editor.commit();
    }

    public String readUserImage(){
        String imgPath = sharedPrefManager.getString(KEY_NAME_USER_IMAGE,"A");
        return imgPath;
    }

}